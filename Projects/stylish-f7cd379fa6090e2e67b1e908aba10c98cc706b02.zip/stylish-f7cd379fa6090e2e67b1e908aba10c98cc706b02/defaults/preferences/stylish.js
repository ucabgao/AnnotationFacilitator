pref("extensions.{46551EC9-40F0-4e47-8E18-8E5CF550CFB8}.description", "chrome://stylish/locale/common.properties");
pref("extensions.stylish.wrap_lines", true);
pref("extensions.stylish.install.allowedDomains", "userstyles.org");
pref("extensions.stylish.styleRegistrationEnabled", true);
pref("extensions.stylish.editOnInstall", false);
pref("extensions.stylish.firstRun", 0);
pref("extensions.stylish.dbFile", "");
pref("extensions.stylish.closedContainers", "");
pref("extensions.stylish.promptOnInstall", true);
pref("extensions.stylish.promptOnClear", true);
pref("extensions.stylish.updatesEnabled", true);
pref("extensions.stylish.editor", 0);

