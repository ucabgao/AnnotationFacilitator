FormFiller
==========

_Stop Wasting Your Time_

The cross-browser Javascript bookmarklet for saving and re-populating forms

```javascript
javascript:(function(){document.body.appendChild(document.createElement('script')).src='https://cdn.rawgit.com/wearecontrast/FormFiller/master/src/FormFiller.js';})();
```
