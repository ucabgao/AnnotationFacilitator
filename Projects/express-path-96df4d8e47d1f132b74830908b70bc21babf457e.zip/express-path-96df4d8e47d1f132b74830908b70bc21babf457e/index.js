// express-path.js
// by @hyubs
// https://github.com/hyubs/express-path.git
module.exports = require('./lib/express-path');