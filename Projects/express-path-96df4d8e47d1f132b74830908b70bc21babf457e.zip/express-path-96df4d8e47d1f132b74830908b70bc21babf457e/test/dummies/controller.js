exports.someFunction = function (req, res) {

};