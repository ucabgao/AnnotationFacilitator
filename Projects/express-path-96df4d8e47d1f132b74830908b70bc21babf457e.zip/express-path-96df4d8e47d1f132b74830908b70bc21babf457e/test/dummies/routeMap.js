module.exports = [
    ['/', 'index#index'],
    ['users/add', 'users#add', 'post'],
    ['users', 'users#list', 'get']
];
